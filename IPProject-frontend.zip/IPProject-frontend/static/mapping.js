async function initMap() {
    // Request needed libraries.
    const { Map } = await google.maps.importLibrary("maps");
    const { AdvancedMarkerElement } = await google.maps.importLibrary("marker");
    const { LatLng } = await google.maps.importLibrary("core");
    const center = new LatLng(56.18142044774992, 15.59097605893871);
    const map = new Map(document.getElementById("map"), {
        zoom: 16,
        center,
        mapId: "4504f8b37365c3d0",
    });

    for (const property of properties) {
        const AdvancedMarkerElement = new google.maps.marker.AdvancedMarkerElement({
            map,
            content: buildContent(property),
            position: property.position,
            title: property.description,
        });

        AdvancedMarkerElement.addListener("click", () => {
            toggleHighlight(AdvancedMarkerElement, property);
        });
    }
}

function toggleHighlight(markerView, property) {
    if (markerView.content.classList.contains("highlight")) {
        markerView.content.classList.remove("highlight");
        markerView.zIndex = null;
    } else {
        markerView.content.classList.add("highlight");
        markerView.zIndex = 1;
    }
}

function buildContent(property) {
    const content = document.createElement("div");

    content.classList.add("property");
    content.innerHTML = `
    <div class="icon">
            <i aria-hidden="true" class="fa fa-icon fa-${property.type}" title="${property.type}"></i>
            <span class="fa-sr-only">${property.type}</span>
    </div>
        <div class="details">
            <div class="test">
                <h1>${property.position.lat}</h1>
        </div>
    </div>
    `;
    return content;
}

const properties = [
    {
        address: "TEST 1",
        description: "CAM 1",
        price: "$ 3,889,000",
        type: "video-camera",
        bed: 5,
        bath: 4.5,
        size: 300,
        position: {
            lat: 56.180982585046095,
            lng: 15.592031521456388,
        },
    },
    {
        address: "TEST 2",
        description: "CAM 2",
        price: "$ 3,889,000",
        type: "home",
        bed: 5,
        bath: 4.5,
        size: 300,
        position: {
            lat: 56.18189320713426,
            lng: 15.590529484464398,
        },
    }
];

initMap();

{/* <div class="price">${property.price}</div>
            <div class="address">${property.address}</div>
            <div class="features">
                <div>
                    <i aria-hidden="true" class="fa fa-bed fa-lg bed" title="bedroom"></i>
                    <span class="fa-sr-only">bedroom</span>
                    <span>${property.bed}</span>
                </div>
                <div>
                    <i aria-hidden="true" class="fa fa-bath fa-lg bath" title="bathroom"></i>
                    <span class="fa-sr-only">bathroom</span>
                    <span>${property.bath}</span>
                </div>
                <div>
                    <i aria-hidden="true" class="fa fa-ruler fa-lg size" title="size"></i>
                    <span class="fa-sr-only">size</span>
                    <span>${property.size} ft<sup>2</sup></span>
                </div>
            </div> */}