from flask import Flask, render_template
from flask_cors import CORS
import json

app = Flask(__name__)
CORS(app, resources={r"/*": {"origins": "*"}})
with open('cameras_config.json') as config_file:
    config = json.load(config_file)
    Cameras = config['Cameras']

@app.route('/')
def index():
    return render_template('index.html', cameras=Cameras)

if __name__ == '__main__':
    app.run(debug=True)
