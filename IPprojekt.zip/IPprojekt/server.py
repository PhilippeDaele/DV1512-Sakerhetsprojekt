from flask import Flask, render_template, request, redirect
from flask_cors import CORS
import json
import logging

app = Flask(__name__)

with open('cameras_config.json') as config_file:
    config = json.load(config_file)
    Cameras = config['Cameras']
    Database = config['Database']

def authenticate_user(username, password):
    if username == Database[0]['username'] and password == Database[0]['password']:
        return 'admin', True
    elif username == Database[1]['username'] and password == Database[1]['password']:
        return 'user', True
    return 'neither', False

@app.route('/login')
def login():
    return render_template('login.html')

@app.route('/')
def go_to_login():
    return redirect('/login')

@app.route('/logout')
def logout():
    # Perform logout actions here (if any)
    return redirect('/login')  # Assuming your login page is at /login


@app.route('/Camera_Hub', methods=['POST'])
def index():
    
    username = request.form.get('username')
    password = request.form.get('password')
    app.logger.info(f"Username: {username}, Password: {password}, {request}")
    userOrAdmin, allowed = authenticate_user(username, password)
    if allowed:
        return render_template('index.html', cameras=Cameras, user=userOrAdmin)
    else:
        return render_template('login.html')

if __name__ == '__main__':
    logging.basicConfig(filename='output.log', level=logging.INFO, format='%(asctime)s [%(levelname)s] %(message)s')
    app.run(debug=False)