from flask import Flask, jsonify
import requests
import threading
import time
import json


app_server = Flask(__name__)

@app_server.route('/')
def index():
    return "Server is running!"

def send_request_to_client(port):
    while True:
        new_status = str(input("Change Status: "))
        if new_status == "None":
            response = requests.get(f'http://localhost:{port}/get_status')
        elif new_status == "" or new_status not in ['Active', 'Inactive']:
            print("Invalid status")
            send_request_to_client(port)
        elif new_status in ['Active', 'Inactive']:
            response = requests.get(f'http://localhost:{port}/set_status?new_status={new_status}&port={port}')
            #print(response.text)
        print(response.text)
        print("\n\n")
        port = int(input("What port?: "))
        #time.sleep(30)

if __name__ == '__main__':
    #with open('config.json') as config_file:
        #config = json.load(config_file)
        #Cameras = config['Cameras']
    
    #for cam_info in Cameras:
        #port = cam_info['port']
        #threading.Thread(target=send_request_to_client, args=(port,"Active")).start()


    # porten borde komma från hmi, men om den ska kolla status så körs raderna ovanför
    print("\n\n")
    port = int(input("What port?: "))
    threading.Thread(target=send_request_to_client, args=(port,)).start()
    app_server.run(debug=False)



