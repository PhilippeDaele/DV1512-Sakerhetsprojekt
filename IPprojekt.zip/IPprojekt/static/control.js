document.addEventListener('DOMContentLoaded', function() {
    const buttons = document.querySelectorAll('.control-button');

    buttons.forEach(button => {
        button.addEventListener('click', function() {
            const port = this.getAttribute('data-port');
            const newStatus = this.getAttribute('data-status');
            const url = `http://localhost:${port}/set_status?new_status=${newStatus}`;
            fetch(url)
                .then(response => response.text())
                .then(data => {
                    const statusElement = document.getElementById(`status-${port}`);
                    statusElement.textContent = `Status: ${newStatus}`;
                });
        });
    });
});