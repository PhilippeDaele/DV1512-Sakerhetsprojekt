document.addEventListener('DOMContentLoaded', function() {
    const checkboxes = document.querySelectorAll('.control-checkbox');

    checkboxes.forEach(checkbox => {
        checkbox.addEventListener('change', function() {
            const port = this.dataset.port;
            const newStatus = this.checked ? 'Active' : 'Inactive';
            const url = `http://localhost:${port}/set_status?new_status=${newStatus}`;
            fetch(url)
                .then(response => response.text())
                .then(data => {
                    const statusElement = document.getElementById(`status-${port}`);
                    const slider = this.parentNode.querySelector('.slider');
                    if (newStatus == "Active") {
                        statusElement.children[0].classList.remove("bg-red-700")
                        statusElement.children[0].classList.add("bg-red-300")
                        statusElement.children[1].classList.add("bg-green-700")
                        statusElement.children[1].classList.remove("bg-green-200")
                        slider.classList.remove("slider-left");
                        slider.classList.add("slider-right");
                    } else {
                        statusElement.children[0].classList.add("bg-red-700")
                        statusElement.children[0].classList.remove("bg-red-300")
                        statusElement.children[1].classList.remove("bg-green-700")
                        statusElement.children[1].classList.add("bg-green-200")
                        slider.classList.remove("slider-right");
                        slider.classList.add("slider-left");
                    }
                });
        });

        // Trigger the change event to ensure correct initial slider position
        checkbox.dispatchEvent(new Event('change'));
    });
});
